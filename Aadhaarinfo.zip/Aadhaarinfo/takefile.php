<?php
//Start the session to see if the user is authencticated user.
session_start();
//Check if the session variable for user authentication is set, if not redirect to login page.
if (!isset($_SESSION['IS_AUTHENTICATED']) && $_SESSION['IS_AUTHENTICATED'] != 1) {
    header('location:login.php');
    exit();
    //include the menu
}
?>


<?php
if ($_POST['submit'] == 'submitfile'){
//Collect POST values
$thumb=$_FILES['thumb'];
$face = $_FILES['face'];
$name = $_POST['user_name'];
if($name){
//Connect to mysql server
$link = mysqli_connect('localhost', 'root', '','aadhaar');
//Check link to the mysql server
if(!$link) {
die('Failed to connect to server: ');
}
//Create query (if you have a Logins table the you can select login id and password from there)
$qry="INSERT INTO `files`(`user_name`, `thumb_image`, `face_image`) VALUES ('$name','$thumb','$face')";
//Execute query
$result=mysqli_query($link, $qry);

if($result&&mysqli_num_rows($result) > 0){
    include('getaadhaar.php');
    echo '<center><h4>Files submitted</h4><center>';
    exit();
}
else{
//Login failed
include('getaadhaar.php');
echo '<center><h4>Files missing!</h4><center>';
exit();
}

}
else{
include('getaadhaar.php');
echo '<center><h4>Files missing!</h4></center>';
exit();
}
}

?>

<?php
//Check if the session variable for user authentication is set, if not redirect to login page.
if (!isset($_SESSION['IS_AUTHENTICATED']) && $_SESSION['IS_AUTHENTICATED'] != 1) {
    header('location:login.php');
    exit();
    //include the menu
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Aadhaar info login</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="styles.css">
</head>
<style>
    .form-container {
        margin: 150px 540px;
        padding: 25px;
    }

    h4 {
        text-align: center;
        padding-bottom: 30px;
    }

    button {
        padding: 20px;
    }

    .buttons {
        padding-bottom: 20px;
    }

    .fonts {
        text-align: center;
        padding-bottom: 30px;
    }

    small {
        padding-bottom: 20px;
    }

    .row {
        padding-left: 100px;
        padding-bottom: 20px;
    }

    hr {
        border-top: 3px solid grey;
        font-size: large;
    }

    a {
        color: white;
    }
    .it {
        padding-right: 25px;
        padding-right: 30px;
    }
    .intro{
        text-align: center;
        padding: 30px;
    }
    .here{
        color: blue;
    }
    .cont{
        text-align: center;
        padding: 10%;
    }
</style>

<body>
      <!-- navigation bar -->
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="index.php">AADHAAR INFO</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a href="index.php" class="nav-link">Home</a>
                </li>
                <li class="nav-tem">
                    <a href="getaadhaar.php" class="nav-link">Get Aadhaar</a>
                </li>
                <li class="nav-item">
                    <a href="help.php" class="nav-link">Help</a>
                </li>
                <li class="nav-item it">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container cont">
        <h1>Files succesfully submitted!</h1>
        <h3>You will get your aadhaar shortly</h3>
    </div>
</body>