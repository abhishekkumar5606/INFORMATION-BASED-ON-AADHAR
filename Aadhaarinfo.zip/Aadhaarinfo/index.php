<?php
//Start the session to see if the user is authencticated user.
session_start();
//Check if the session variable for user authentication is set, if not redirect to login page.
if (!isset($_SESSION['IS_AUTHENTICATED']) && $_SESSION['IS_AUTHENTICATED'] != 1) {
    header('location:login.php');
    exit();
    //include the menu
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <title>Aadhaar Info</title>
</head>
<style>
    .it {
        padding-right: 25px;
        padding-right: 30px;
    }

    .intro {
        text-align: center;
        padding: 30px;
    }
</style>

<body>

    <!-- navigation bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="index.php">AADHAAR INFO</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a href="index.php" class="nav-link">Home</a>
                </li>
                <li class="nav-tem">
                    <a href="getaadhaar.php" class="nav-link">Get Aadhaar</a>
                </li>
                <li class="nav-item">
                    <a href="help.php" class="nav-link">Help</a>
                </li>
                <li class="nav-item it">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- carousels -->
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img class="d-block w-100" src="car3.jpg" alt="First slide" height="580px">
            </div>
            <div class="carousel-item">
                <img class="d-block w-100" src="car2.jpg" alt="Second slide" height="580px">
            </div>
            <div class="carousel-item">
                <img class="d-block w-100" src="car1.jpg" alt="Third slide" height="580px">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <!-- E-aadhaar  -->
    <div class="container">
        <h3 class="intro">E-Aadhaar</h3>
        <p>E-aadhaar is an Aadhaar in digitised format. It is provided by UIDAI (Unique Identification Authority of India) which enables people to download and access their aadhaar anywhere and anytime by using thumbprint as well as using facecam. It comes in a digital format which is protected by a password so that no other person can access it. So it can be used as a valid ID proof for opening a bank account, enrolling to an insurance policy etc. It helps us to avoid carrying the original aadhaar to avoid risk of losing it.</p>
    </div>

    <!-- steps to download E-aadhaar  -->
    <div class="container">
        <h3 class="intro">How to download E-aadhaar?</h3>
        <p>To download E-aadhaar through thumbprint and facecam, click <a href="getaadhaar.php">here</a>. You will be directed to our website. To upload thumbprint through phone you can directly use scanner or through pc/max you can will be directed to a page through the link present below the thumbprint. You can either turn on face cam or upload clear pic of yours. After submitting both thumbprint and facecam you can upload and you will recieve your E-aadhaar within 10-15 min after uploading.</p>
    </div>

    <!-- Privacy promises -->
    <div class="container">
        <h3 class="intro">Privacy</h3>
        <p>The Aadhaar you get will be protected by password so only the user can access it. We promise that we donot share the image or thumbrint of user.</p>
    </div>
</body>

</html>