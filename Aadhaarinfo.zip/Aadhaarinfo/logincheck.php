<?php
if ($_POST['submit'] == 'login'){
//Collect POST values
$login = $_POST['user_contact'];
$Password = $_POST['user_password'];
if($login && $Password){
//Connect to mysql server
$link = mysqli_connect('localhost', 'root', '','aadhaar');
//Check link to the mysql server
if(!$link) {
die('Failed to connect to server: ');
}
//Create query (if you have a Logins table the you can select login id and password from there)
$qry="SELECT * FROM users WHERE user_contact = '$login' AND user_password = '$Password' limit 1";
//Execute query
$result=mysqli_query($link, $qry);

if($result&&mysqli_num_rows($result) > 0){
  session_start();
  $_SESSION['IS_AUTHENTICATED'] = 1;
  $_SESSION['USER_ID'] = $login;
  header('location:index.php');
}
else{
//Login failed
include('login.php');
echo '<center><h4>Incorrect Username or Password 1!</h4><center>';
exit();
}

}
else{
include('login.php');
echo '<center><h4>Username or Password missing 2!</h4></center>';
exit();
}
}

else if ($_POST['submit'] == 'loginadmin'){
  //Collect POST values
  $login = $_POST['user_contact'];
  $Password = $_POST['user_password'];
  if($login && $Password){
  //Connect to mysql server
  $link = mysqli_connect('localhost', 'root', '','aadhaar');
  //Check link to the mysql server
  if(!$link) {
  die('Failed to connect to server: ');
  }
  //Create query (if you have a Logins table the you can select login id and password from there)
  $qry="SELECT * FROM admins WHERE user_contact = '$login' AND user_password = '$Password' limit 1";
  //Execute query
  $result=mysqli_query($link, $qry);
  
  if($result&&mysqli_num_rows($result) > 0){
    session_start();
    $_SESSION['IS_AUTHENTICATED'] = 1;
    $_SESSION['USER_ID'] = $login;
    header('location:admin.php');
  }
  else{
  //Login failed
  include('login.php');
  echo '<center><h4>Incorrect Username or Password 1!</h4><center>';
  exit();
  }
  
  }
  else{
  include('login.php');
  echo '<center><h4>Username or Password missing 2!</h4></center>';
  exit();
  }
  }
