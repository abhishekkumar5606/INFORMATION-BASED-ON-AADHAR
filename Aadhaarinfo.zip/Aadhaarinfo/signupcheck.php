<?php
if ($_POST['submit'] == 'signup'){
//Collect POST values
$Password = $_POST['user_password'];
$CnfPassword = $_POST['confirm_password'];
$name = $_POST['user_name'];
$mobile = $_POST['user_contact'];

if(($Password == $CnfPassword) && $Password && $CnfPassword){
//Connect to mysql server
$link = mysqli_connect('localhost', 'root', '','aadhaar');
//Check link to the mysql server
if(!$link) {
die('Failed to connect to server: ');
}
$qry1="SELECT * FROM users WHERE user_contact = '$mobile' limit 1";
$result1=mysqli_query($link, $qry1);

if($result1&&mysqli_num_rows($result1) > 0){
  include('signup.php');
  echo '<center><h4>User contact is already in use!</h4><center>';
}
//Create query (if you have a Logins table the you can select login id and password from there)
else{
  $qry="INSERT into register (user_name, user_contact, user_password) values ('$name', '$mobile', '$Password')";
  //Execute query
  $result=mysqli_query($link, $qry);

  if($result){
    //session_start();
    $qry2="INSERT into users (user_contact, user_password) values ('$mobile', '$Password')";
    $result2=mysqli_query($link,$qry2);
    $_SESSION['IS_AUTHENTICATED'] = 1;
    include('signup.php');
    echo '<center><h4>You have been successfully signed Up. Go back to Login page to Login</h4><center>';
  }
  else{
  //Login failed
  include('signup.php');
  echo '<center><h4>Incorrect Username or Password!</h4><center>';
  exit();
  }
}

}
else if($mobile){
  include('signup.php');
  if ($password) {
    echo '<center><h4>Entered Passwords Not matched!</h4></center>';
  }
  else{
    echo '<center><h4>Enter All Details!</h4></center>';
  }

exit();
}
else{
  include('signup.php');
  echo '<center><h4>Enter All Details!</h4></center>';
  exit();
}
}
else{
header("location: signup.php");
exit();
}

?>
