<?php
//Start the session to see if the user is authencticated user.
session_start();
//Check if the session variable for user authentication is set, if not redirect to login page.
if (!isset($_SESSION['IS_AUTHENTICATED']) && $_SESSION['IS_AUTHENTICATED'] != 1) {
    header('location:login.php');
    exit();
    //include the menu
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <title>Aadhaar Info</title>
</head>
<style>
    .it {
        padding-right: 25px;
        padding-right: 30px;
    }

    .intro {
        text-align: center;
        padding: 30px;
    }
</style>

<body>

    <!-- navigation bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="index.php">AADHAAR INFO</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a href="index.php" class="nav-link">Home</a>
                </li>
                <li class="nav-tem">
                    <a href="getaadhaar.php" class="nav-link">Get Aadhaar</a>
                </li>
                <li class="nav-item">
                    <a href="help.php" class="nav-link">Help</a>
                </li>
                <li class="nav-item it">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- to upload thumbprint  -->
    <div class="container">
        <h3 class="intro">How to upload thumbprint?</h3>
        <p>You can Upload thumbprint in either ways</p>
        <ol>
            <li><h5>Using paper and blue ink</h5>
            <p> Take a white paper, dip your thumb in any ink preferably blue and  paste it over paper..By this you will be able to get your thumb impression on a paper. Scan the paper using <a href="https://www.camscanner.com/login" target="_blank">Cam Scanner</a>and upload the file in jpg format.</p>
            </li>
            <li><h5>Use thumbprint scanner app in mobile</h5>
            <p>Install thumbprint app from <a href="https://play.google.com/store" target="_blank">Play store</a> and place your thumb as directed by app. Upload the file in JPG format.</p>
            </li>
        </ol>
    </div>

    <!-- to upload image  -->
    <div class="container">
        <h3 class="intro">How to upload Image?</h3>
        <p>You can Upload image in either ways</p>
        <ol>
            <li><h5>Scan a passport size photo</h5>
            <p>Scan a recent passport size photograph of yours using<a href="https://www.camscanner.com/login" target="_blank">Cam Scanner</a> and upload the same in JPG format.</p>
            </li>
            <li><h5>Use mobile camera</h5>
            <p>Give permission for the website to use camera and take a picture of yours( using front camera) with preferably dark background to get clear picture and upload the same.</p>
            </li>
        </ol>
    </div>

    <!-- Didnot recieve aadhaar  -->
    <div class="container">
        <h3 class="intro">Didn't recieve aadhaar even after Uploading the images as instructed?</h3>
        <ol>
            <li>The images that you've uploaded may not be clear so there might be an issue which checking it.</li>
            <li>Make sure that thumbprint is erect and undisturbed and not crossed as disturbed thumbrint or cross thumbprint will not match the original one.</li>
            <li>Make sure that face is clear and not blurr. Blurr images donot match the original image so it is difficult to find original aadhaar.</li>
            <li>Make sure that pictures are not dark so that they can be visible while scannning.</li>
        </ol>
    </div>